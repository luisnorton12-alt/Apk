# Derecho Laboral Master (MVP – Fase 1)

App Flutter (Android, offline con SQLite) para estudiar la Ley Federal del Trabajo.

## Compilar
**Opción A – GitHub (sin instalar nada):** sube esta carpeta a un repositorio; en la pestaña *Actions* descarga el artefacto `derecho-laboral-master-apk`.

**Opción B – Local:**
```
flutter create --platforms=android --project-name derecho_laboral_master --org mx.derecholaboral .
flutter pub get
flutter build apk --release
```
APK: `build/app/outputs/flutter-apk/app-release.apk`

## Estructura
- `lib/main.dart` tema (azul marino/blanco/dorado, claro y oscuro) y arranque
- `lib/db.dart` SQLite, repetición espaciada, estadísticas, importador del texto oficial
- `lib/gen.dart` generador de preguntas y tarjetas a partir del texto de cada artículo
- `lib/screens.dart` todas las pantallas
- `assets/` artículos de muestra, casos prácticos, glosario

## Contenido legal
`lft_muestra.json` trae solo 5 artículos de muestra: verifica su texto contra la fuente oficial (https://www.diputados.gob.mx/LeyesBiblio/). Para la ley completa: Ajustes → Importar texto oficial (.txt).
