import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

const navy = Color(0xFF0B2545), oro = Color(0xFFC9A227);
final modo = ValueNotifier<ThemeMode>(ThemeMode.system);
int metaDiaria = 10;
int hoy() => DateTime.now().millisecondsSinceEpoch ~/ 86400000;

class Art {
  final Map<String, Object?> m;
  Art(this.m);
  String get num => m['num'] as String;
  String get texto => (m['texto'] as String?) ?? '';
  String get titulo => (m['titulo'] as String?) ?? '';
  String get capitulo => (m['capitulo'] as String?) ?? '';
  String get estado => (m['estado'] as String?) ?? 'pendiente';
  bool get fav => (m['fav'] ?? 0) == 1;
  String? s(String k) {
    final v = m[k] as String?;
    return (v == null || v.trim().isEmpty) ? null : v;
  }
}

class DB {
  static late Database d;
  static const _sel =
      "SELECT a.*, COALESCE(p.estado,'pendiente') estado, COALESCE(p.fav,0) fav FROM articulos a LEFT JOIN progreso p ON p.num=a.num";

  static int orden(String num) {
    final mt = RegExp(r'^(\d+)\s*(.*)$').firstMatch(num)!;
    final suf = mt.group(2)!.toLowerCase();
    const esp = {'bis': 1, 'ter': 2, 'quater': 3, 'quáter': 3};
    final o = esp[suf] ?? (suf.isEmpty ? 0 : 10 + suf.codeUnitAt(0) - 96);
    return int.parse(mt.group(1)!) * 100 + o;
  }

  static Future<void> init() async {
    d = await openDatabase(p.join(await getDatabasesPath(), 'dlm.db'), version: 1,
        onCreate: (db, _) async {
      await db.execute(
          'CREATE TABLE articulos(num TEXT PRIMARY KEY, orden INTEGER, titulo TEXT, capitulo TEXT, texto TEXT, explicacion TEXT, claves TEXT, ejemplo TEXT, relaciones TEXT, preguntas TEXT, procedimiento TEXT)');
      await db.execute(
          'CREATE TABLE progreso(num TEXT PRIMARY KEY, estado TEXT, fav INTEGER, ef REAL, inter INTEGER, due INTEGER, aciertos INTEGER, fallos INTEGER)');
      await db.execute(
          'CREATE TABLE examenes(id INTEGER PRIMARY KEY AUTOINCREMENT, fecha INTEGER, aciertos INTEGER, total INTEGER)');
      await db.execute('CREATE TABLE dias(dia INTEGER PRIMARY KEY, n INTEGER)');
      final raw = jsonDecode(await rootBundle.loadString('assets/lft_muestra.json')) as List;
      for (final a in raw) {
        final r = Map<String, Object?>.from(a as Map);
        r['orden'] = orden(r['num'] as String);
        await db.insert('articulos', r);
      }
    });
  }

  static Future<List<Art>> todos() async =>
      (await d.rawQuery('$_sel ORDER BY a.orden')).map(Art.new).toList();

  static Future<Art?> art(String n) async {
    final r = await d.rawQuery('$_sel WHERE a.num=?', [n]);
    return r.isEmpty ? null : Art(r.first);
  }

  static Future<List<String>> titulos() async => (await d.rawQuery(
          "SELECT titulo FROM articulos WHERE titulo<>'' GROUP BY titulo ORDER BY MIN(orden)"))
      .map((r) => r['titulo'] as String)
      .toList();

  static Future<void> _asegura(String n) => d.insert(
      'progreso',
      {'num': n, 'estado': 'pendiente', 'fav': 0, 'ef': 2.5, 'inter': 0, 'due': 0, 'aciertos': 0, 'fallos': 0},
      conflictAlgorithm: ConflictAlgorithm.ignore);

  static Future<void> setEstado(String n, String e) async {
    await _asegura(n);
    await d.update('progreso', {'estado': e}, where: 'num=?', whereArgs: [n]);
  }

  static Future<void> setFav(String n, bool f) async {
    await _asegura(n);
    await d.update('progreso', {'fav': f ? 1 : 0}, where: 'num=?', whereArgs: [n]);
  }

  // q: 0 otra vez, 3 difícil, 4 bien, 5 fácil (SM-2 simplificado)
  static Future<void> calificar(String n, int q) async {
    await _asegura(n);
    final r = (await d.query('progreso', where: 'num=?', whereArgs: [n])).first;
    double ef = (r['ef'] as num).toDouble();
    int inter = r['inter'] as int;
    if (q == 0) {
      inter = 0;
      ef = max(1.3, ef - 0.2);
    } else {
      final f = q == 3 ? 0.8 : (q == 5 ? 1.3 : 1.0);
      inter = inter == 0 ? (q == 5 ? 3 : 1) : (inter * ef * f).round().clamp(1, 365).toInt();
      ef = max(1.3, ef + (q == 5 ? 0.1 : (q == 3 ? -0.15 : 0.0)));
    }
    final estado = (q == 0 || inter < 21) ? 'proceso' : 'aprendido';
    await d.rawUpdate(
        'UPDATE progreso SET ef=?, inter=?, due=?, estado=?, ${q == 0 ? 'fallos=fallos+1' : 'aciertos=aciertos+1'} WHERE num=?',
        [ef, inter, hoy() + inter, estado, n]);
    await d.insert('dias', {'dia': hoy(), 'n': 0}, conflictAlgorithm: ConflictAlgorithm.ignore);
    await d.rawUpdate('UPDATE dias SET n=n+1 WHERE dia=?', [hoy()]);
  }

  static Future<List<Art>> cola() async {
    final h = hoy();
    final venc = await d.rawQuery(
        "$_sel WHERE p.num IS NOT NULL AND p.estado<>'pendiente' AND p.due<=$h ORDER BY p.due");
    final nuevos = await d.rawQuery(
        "$_sel WHERE COALESCE(p.estado,'pendiente')='pendiente' ORDER BY a.orden LIMIT $metaDiaria");
    return [...venc, ...nuevos].map(Art.new).toList();
  }

  static Future<void> guardarExamen(int ac, int total) =>
      d.insert('examenes', {'fecha': hoy(), 'aciertos': ac, 'total': total});

  static Future<void> reiniciar() async {
    for (final t in ['progreso', 'examenes', 'dias']) {
      await d.delete(t);
    }
  }

  static Future<Map<String, dynamic>> stats() async {
    final tot = Sqflite.firstIntValue(await d.rawQuery('SELECT COUNT(*) FROM articulos')) ?? 0;
    final est = await d.rawQuery('SELECT estado, COUNT(*) c FROM progreso GROUP BY estado');
    int g(String e) => est.where((r) => r['estado'] == e).map((r) => r['c'] as int).fold(0, (a, b) => a + b);
    final ex = (await d.rawQuery(
            'SELECT COALESCE(SUM(aciertos),0) a, COALESCE(SUM(total),0) t, COUNT(*) n FROM examenes'))
        .first;
    final dias = (await d.rawQuery('SELECT dia FROM dias WHERE n>0 ORDER BY dia DESC'))
        .map((r) => r['dia'] as int)
        .toList();
    int racha = 0;
    int esp = (dias.isNotEmpty && dias.first == hoy()) ? hoy() : hoy() - 1;
    for (final x in dias) {
      if (x == esp) {
        racha++;
        esp--;
      } else if (x < esp) {
        break;
      }
    }
    final ref = await d.rawQuery(
        'SELECT a.num, p.fallos, p.aciertos FROM progreso p JOIN articulos a ON a.num=p.num WHERE p.fallos>0 AND p.fallos>=p.aciertos ORDER BY p.fallos DESC LIMIT 10');
    return {
      'total': tot, 'aprendidos': g('aprendido'), 'proceso': g('proceso'),
      'ex': ex, 'racha': racha, 'dias': dias.length, 'ref': ref
    };
  }

  static String _une(List<String> ls) {
    final sb = StringBuffer();
    for (var i = 0; i < ls.length; i++) {
      sb.write(ls[i]);
      if (i < ls.length - 1) sb.write(RegExp(r'[\.:;]$').hasMatch(ls[i]) ? '\n' : ' ');
    }
    return sb.toString().trim();
  }

  /// Importa el texto oficial de la LFT (.txt). Conserva las explicaciones ya existentes.
  static Future<int> importar(String txt) async {
    final art = RegExp(
        r'^\s*(?:[Aa]rt[íi]culo|ARTÍCULO)\s+(\d+)\s*(?:o\.|º|°)?\s*(-?[A-Z]|Bis|Ter|Qu[aá]ter)?\s*[\.\-–—]*\s*(.*)$');
    final skip = RegExp(
        r'^\s*(Ley Federal del Trabajo|CÁMARA DE DIPUTADOS|Secretar[íi]a (General|de Servicios)|[ÚU]ltima [Rr]eforma|P[áa]gina \d+)|^\s*\d+\s+de\s+\d+\s*$');
    final tRe = RegExp(r'^T[ÍI]TULO\s', caseSensitive: false);
    final cRe = RegExp(r'^CAP[ÍI]TULO\s', caseSensitive: false);
    final recs = <Map<String, Object?>>[];
    String tit = '', cap = '';
    String? cur, ap;
    var buf = <String>[];
    int last = -1;
    void cierra() {
      if (cur != null) {
        recs.add({'num': cur, 'titulo': tit, 'capitulo': cap, 'texto': _une(buf)});
      }
    }

    for (final raw in txt.split(RegExp(r'\r?\n'))) {
      final l = raw.trim();
      if (l.isEmpty || skip.hasMatch(l)) continue;
      final mt = art.firstMatch(l);
      if (mt != null) {
        final suf = (mt.group(2) ?? '').replaceAll('-', '');
        final nm = suf.isEmpty ? mt.group(1)! : '${mt.group(1)} $suf';
        final o = orden(nm);
        if (o > last) {
          cierra();
          cur = nm;
          last = o;
          buf = [mt.group(3) ?? ''];
          ap = null;
          continue;
        }
      }
      if (tRe.hasMatch(l)) {
        cierra(); cur = null; buf = []; tit = l; cap = ''; ap = 't';
      } else if (cRe.hasMatch(l)) {
        cierra(); cur = null; buf = []; cap = l; ap = 'c';
      } else if (ap != null && cur == null && l.length < 100) {
        if (ap == 't') { tit = '$tit — $l'; } else { cap = '$cap — $l'; }
        ap = null;
      } else if (cur != null) {
        buf.add(l);
      }
    }
    cierra();
    await d.transaction((t) async {
      for (final r in recs) {
        final o = orden(r['num'] as String);
        final c = await t.update('articulos',
            {'titulo': r['titulo'], 'capitulo': r['capitulo'], 'texto': r['texto'], 'orden': o},
            where: 'num=?', whereArgs: [r['num']]);
        if (c == 0) await t.insert('articulos', {...r, 'orden': o});
      }
    });
    return recs.length;
  }
}
