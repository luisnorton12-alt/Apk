import 'dart:math';
import 'db.dart';

final _r = Random();

class Preg {
  final String tipo, enunciado;
  final List<String> ops;
  final int ok;
  final Art art;
  Preg(this.tipo, this.enunciado, this.ops, this.ok, this.art);
}

String frag(String t, [int n = 220]) {
  final s = t.replaceAll('\n', ' ');
  if (s.length <= n) return s;
  final c = s.lastIndexOf(' ', n);
  return '${s.substring(0, c > 0 ? c : n)}…';
}

List<String> palabras(String t) =>
    RegExp(r'[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{7,}').allMatches(t).map((m) => m.group(0)!).toList();

(String, List<String>) cloze(String t, [int k = 3]) {
  final ps = palabras(t).toSet().toList()..shuffle(_r);
  final sel = ps.take(k).toList();
  var s = t;
  for (final w in sel) {
    s = s.replaceFirst(w, '_____');
  }
  return (s, sel);
}

Preg _tipoNum(Art a, List<Art> otros) {
  final ops = <String>['Art. ${a.num}', ...otros.take(3).map((o) => 'Art. ${o.num}')]..shuffle(_r);
  return Preg('Identifica el artículo', '¿Qué artículo establece lo siguiente?\n\n“${frag(a.texto)}”',
      ops, ops.indexOf('Art. ${a.num}'), a);
}

List<Preg> generar(List<Art> pool, int n) {
  final arts = pool.where((a) => a.texto.length > 40).toList()..shuffle(_r);
  if (arts.length < 2) return [];
  final res = <Preg>[];
  final total = min(n, arts.length * 2);
  for (var i = 0; i < total; i++) {
    final a = arts[i % arts.length];
    final otros = (List<Art>.from(arts)..remove(a))..shuffle(_r);
    final t = _r.nextInt(3);
    if (t == 1) {
      final verd = _r.nextBool();
      res.add(Preg('Verdadero o falso',
          'El Art. ${a.num} establece:\n\n“${frag((verd ? a : otros.first).texto, 180)}”',
          ['Verdadero', 'Falso'], verd ? 0 : 1, a));
    } else if (t == 2) {
      final base = frag(a.texto, 220);
      final ps = palabras(base).toSet().toList()..shuffle(_r);
      if (ps.isEmpty) {
        res.add(_tipoNum(a, otros));
        continue;
      }
      final w = ps.first;
      final ds = otros
          .expand((o) => palabras(o.texto))
          .where((x) => x.toLowerCase() != w.toLowerCase())
          .toSet()
          .toList()
        ..shuffle(_r);
      if (ds.length < 2) {
        res.add(_tipoNum(a, otros));
        continue;
      }
      final ops = <String>[w, ...ds.take(3)]..shuffle(_r);
      res.add(Preg('Completa el texto', 'Art. ${a.num}:\n\n“${base.replaceFirst(w, '_____')}”', ops,
          ops.indexOf(w), a));
    } else {
      res.add(_tipoNum(a, otros));
    }
  }
  return res;
}
