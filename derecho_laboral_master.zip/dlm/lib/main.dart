import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'db.dart';
import 'screens.dart';

ThemeData tema(Brightness b) {
  final d = b == Brightness.dark;
  final cs = ColorScheme.fromSeed(seedColor: navy, brightness: b)
      .copyWith(primary: d ? const Color(0xFF9DB7E8) : navy, secondary: oro);
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
    filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(backgroundColor: oro, foregroundColor: navy)),
  );
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final sp = await SharedPreferences.getInstance();
  modo.value = ThemeMode.values[sp.getInt('modo') ?? 0];
  metaDiaria = sp.getInt('meta') ?? 10;
  await DB.init();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
        valueListenable: modo,
        builder: (_, m, __) => MaterialApp(
          title: 'Derecho Laboral Master',
          debugShowCheckedModeBanner: false,
          theme: tema(Brightness.light),
          darkTheme: tema(Brightness.dark),
          themeMode: m,
          home: const Home(),
        ),
      );
}
