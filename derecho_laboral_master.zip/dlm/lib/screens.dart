import 'dart:convert';
import 'dart:math';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';
import 'db.dart';
import 'gen.dart';

final _rnd = Random();
void ir(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));
Future<List> _json(String f) async => jsonDecode(await rootBundle.loadString('assets/$f')) as List;

Widget seccion(BuildContext c, String t, String? x) => x == null
    ? const SizedBox.shrink()
    : Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t, style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(c).colorScheme.secondary)),
            const SizedBox(height: 6),
            SelectableText(x, style: const TextStyle(height: 1.4)),
          ]),
        ),
      );

// ───────────── HOME ─────────────
class Home extends StatelessWidget {
  const Home({super.key});
  @override
  Widget build(BuildContext c) {
    final items = <(IconData, String, String, Widget)>[
      (Icons.menu_book, 'Estudiar', 'Biblioteca y fichas', const Estudiar()),
      (Icons.style, 'Memorizar', 'Flashcards y repaso', const Memorizar()),
      (Icons.quiz, 'Exámenes', 'Con fundamento legal', const Examen()),
      (Icons.gavel, 'Casos prácticos', 'Analiza y compara', const Casos()),
      (Icons.library_books, 'Diccionario', 'Conceptos clave', const Glosario()),
      (Icons.insights, 'Mi progreso', 'Estadísticas y rachas', const Progreso()),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Derecho Laboral Master'), actions: [
        IconButton(icon: const Icon(Icons.settings), onPressed: () => ir(c, const Ajustes())),
      ]),
      body: GridView.count(
        crossAxisCount: 2,
        padding: const EdgeInsets.all(12),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        children: [
          for (final (ic, t, s, w) in items)
            Card(
              child: InkWell(
                onTap: () => ir(c, w),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(ic, size: 40, color: Theme.of(c).colorScheme.secondary),
                    const SizedBox(height: 8),
                    Text(t, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16), textAlign: TextAlign.center),
                    Text(s, style: const TextStyle(fontSize: 12), textAlign: TextAlign.center),
                  ]),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ───────────── ESTUDIAR ─────────────
class Estudiar extends StatefulWidget {
  const Estudiar({super.key});
  @override
  State<Estudiar> createState() => _EstudiarS();
}

class _EstudiarS extends State<Estudiar> {
  List<Art> arts = [];
  String q = '', f = 'todos';
  @override
  void initState() {
    super.initState();
    cargar();
  }

  Future<void> cargar() async {
    final r = await DB.todos();
    if (mounted) setState(() => arts = r);
  }

  @override
  Widget build(BuildContext c) {
    final ql = q.toLowerCase();
    final l = arts
        .where((a) =>
            (f == 'todos' || (f == 'fav' ? a.fav : a.estado == f)) &&
            (ql.isEmpty ||
                a.num.toLowerCase().startsWith(ql) ||
                a.texto.toLowerCase().contains(ql) ||
                (a.s('claves') ?? '').toLowerCase().contains(ql)))
        .toList();
    final kids = <Widget>[];
    for (var i = 0; i < l.length; i++) {
      final a = l[i];
      final h = [a.titulo, a.capitulo].where((x) => x.isNotEmpty).join('\n');
      if (h.isNotEmpty && (i == 0 || l[i - 1].titulo != a.titulo || l[i - 1].capitulo != a.capitulo)) {
        kids.add(Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
            child: Text(h, style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(c).colorScheme.secondary))));
      }
      kids.add(ListTile(
        leading: Icon(
            a.estado == 'aprendido' ? Icons.check_circle : (a.estado == 'proceso' ? Icons.timelapse : Icons.radio_button_unchecked),
            color: a.estado == 'aprendido' ? Colors.green : null),
        title: Text('Art. ${a.num}'),
        subtitle: Text(frag(a.texto, 100), maxLines: 2, overflow: TextOverflow.ellipsis),
        trailing: a.fav ? const Icon(Icons.star, color: oro) : null,
        onTap: () async {
          await Navigator.push(c, MaterialPageRoute(builder: (_) => Ficha(a)));
          cargar();
        },
      ));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Estudiar artículos')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: TextField(
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Buscar por número o texto', border: OutlineInputBorder()),
              onChanged: (v) => setState(() => q = v.trim())),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Row(children: [
            for (final (k, t) in [('todos', 'Todos'), ('fav', '★ Favoritos'), ('pendiente', 'Pendientes'), ('proceso', 'En proceso'), ('aprendido', 'Aprendidos')])
              Padding(padding: const EdgeInsets.all(4), child: ChoiceChip(label: Text(t), selected: f == k, onSelected: (_) => setState(() => f = k))),
          ]),
        ),
        if (arts.length < 50)
          Card(
              margin: const EdgeInsets.all(12),
              child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text('Biblioteca de muestra: ${arts.length} artículos. Importa el texto oficial completo en Ajustes (⚙).', style: const TextStyle(fontSize: 13)))),
        Expanded(child: ListView(children: kids)),
      ]),
    );
  }
}

class Ficha extends StatefulWidget {
  final Art a;
  const Ficha(this.a, {super.key});
  @override
  State<Ficha> createState() => _FichaS();
}

class _FichaS extends State<Ficha> {
  late String estado = widget.a.estado;
  late bool fav = widget.a.fav;
  @override
  Widget build(BuildContext c) {
    final a = widget.a;
    return Scaffold(
      appBar: AppBar(title: Text('Artículo ${a.num}'), actions: [
        IconButton(
            icon: Icon(fav ? Icons.star : Icons.star_border, color: oro),
            onPressed: () async {
              await DB.setFav(a.num, !fav);
              setState(() => fav = !fav);
            }),
      ]),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        if (a.titulo.isNotEmpty) Text([a.titulo, a.capitulo].where((x) => x.isNotEmpty).join('\n'), style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'pendiente', label: Text('Pendiente')),
            ButtonSegment(value: 'proceso', label: Text('En proceso')),
            ButtonSegment(value: 'aprendido', label: Text('Aprendido')),
          ],
          selected: {estado},
          onSelectionChanged: (s) async {
            await DB.setEstado(a.num, s.first);
            setState(() => estado = s.first);
          },
        ),
        seccion(c, 'Texto legal', a.texto),
        a.s('explicacion') == null
            ? seccion(c, 'En palabras sencillas', 'Este artículo aún no tiene explicación didáctica incluida.')
            : seccion(c, 'En palabras sencillas', a.s('explicacion')),
        seccion(c, 'Palabras clave', a.s('claves')),
        seccion(c, 'Ejemplo real', a.s('ejemplo')),
        seccion(c, 'Relación con otros artículos', a.s('relaciones')),
        seccion(c, 'Comprueba tu comprensión', a.s('preguntas')),
        seccion(c, 'Uso en un procedimiento laboral', a.s('procedimiento')),
      ]),
    );
  }
}

// ───────────── MEMORIZAR ─────────────
class Memorizar extends StatefulWidget {
  const Memorizar({super.key});
  @override
  State<Memorizar> createState() => _MemS();
}

class _MemS extends State<Memorizar> {
  List<Art> cola = [];
  int i = 0;
  bool cargando = true, ver = false, cl = false;
  String ct = '';
  List<String> ca = [];
  @override
  void initState() {
    super.initState();
    DB.cola().then((r) {
      cola = r;
      _prep();
      if (mounted) setState(() => cargando = false);
    });
  }

  void _prep() {
    ver = false;
    if (i < cola.length) {
      final a = cola[i];
      cl = a.texto.length > 60 && _rnd.nextBool();
      if (cl) {
        final (s, w) = cloze(frag(a.texto, 350));
        ct = s;
        ca = w;
      }
    }
  }

  Future<void> _rate(int q) async {
    final a = cola[i];
    await DB.calificar(a.num, q);
    if (q == 0) cola.add(a);
    setState(() {
      i++;
      _prep();
    });
  }

  @override
  Widget build(BuildContext c) {
    Widget cuerpo;
    if (cargando) {
      cuerpo = const Center(child: CircularProgressIndicator());
    } else if (i >= cola.length) {
      cuerpo = Center(
          child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(cola.isEmpty ? 'No tienes tarjetas por hoy. Vuelve mañana o aumenta tu meta diaria en Ajustes.' : '¡Sesión completada! Tus repasos quedaron programados.',
                  textAlign: TextAlign.center, style: const TextStyle(fontSize: 18))));
    } else {
      final a = cola[i];
      cuerpo = ListView(padding: const EdgeInsets.all(16), children: [
        LinearProgressIndicator(value: i / cola.length),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Artículo ${a.num}', style: Theme.of(c).textTheme.titleLarge),
              const SizedBox(height: 10),
              if (!ver)
                Text(cl ? 'Completa los espacios:\n\n$ct' : 'Recuerda qué establece.${a.s('claves') != null ? '\n\nPistas: ${a.s('claves')}' : ''}',
                    style: const TextStyle(fontSize: 16, height: 1.4))
              else ...[
                if (cl) Text('Respuestas: ${ca.join(', ')}\n', style: const TextStyle(fontWeight: FontWeight.bold)),
                SelectableText(a.texto),
                if (a.s('explicacion') != null) Text('\nEn sencillo: ${a.s('explicacion')}'),
              ],
            ]),
          ),
        ),
        const SizedBox(height: 12),
        if (!ver)
          FilledButton(onPressed: () => setState(() => ver = true), child: const Text('Mostrar respuesta'))
        else
          Row(children: [
            for (final (t, q) in [('Otra vez', 0), ('Difícil', 3), ('Bien', 4), ('Fácil', 5)])
              Expanded(child: Padding(padding: const EdgeInsets.all(2), child: FilledButton(onPressed: () => _rate(q), child: Text(t, style: const TextStyle(fontSize: 12))))),
          ]),
      ]);
    }
    return Scaffold(appBar: AppBar(title: const Text('Memorizar')), body: cuerpo);
  }
}

// ───────────── EXAMEN ─────────────
class Examen extends StatefulWidget {
  const Examen({super.key});
  @override
  State<Examen> createState() => _ExS();
}

class _ExS extends State<Examen> {
  List<Art> todos = [];
  List<String> tits = [];
  String tit = 'Todos';
  int n = 10;
  bool soloFav = false, fin = false;
  List<Preg>? ps;
  int i = 0, ok = 0;
  int? sel;
  String? err;
  @override
  void initState() {
    super.initState();
    DB.todos().then((a) async {
      final t = await DB.titulos();
      if (mounted) setState(() { todos = a; tits = t; });
    });
  }

  void start() {
    final pool = todos.where((a) => (tit == 'Todos' || a.titulo == tit) && (!soloFav || a.fav)).toList();
    final g = generar(pool, n);
    setState(() {
      if (g.isEmpty) {
        err = 'Se necesitan al menos 2 artículos con texto en esa selección.';
      } else {
        ps = g; i = 0; ok = 0; sel = null; fin = false; err = null;
      }
    });
  }

  Future<void> resp(int k) async {
    final p = ps![i];
    final acierto = k == p.ok;
    setState(() { sel = k; if (acierto) ok++; });
    await DB.calificar(p.art.num, acierto ? 3 : 0);
  }

  Future<void> sig() async {
    if (i + 1 >= ps!.length) {
      await DB.guardarExamen(ok, ps!.length);
      setState(() => fin = true);
    } else {
      setState(() { i++; sel = null; });
    }
  }

  @override
  Widget build(BuildContext c) {
    Widget cuerpo;
    if (ps == null || fin) {
      cuerpo = ListView(padding: const EdgeInsets.all(16), children: [
        if (fin) Card(child: Padding(padding: const EdgeInsets.all(16), child: Text('Resultado: $ok de ${ps!.length} (${(100 * ok / ps!.length).round()}%)', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)))),
        const Text('Alcance'),
        DropdownButton<String>(
            isExpanded: true,
            value: tit,
            items: [for (final t in ['Todos', ...tits]) DropdownMenuItem(value: t, child: Text(t, overflow: TextOverflow.ellipsis))],
            onChanged: (v) => setState(() => tit = v!)),
        SwitchListTile(title: const Text('Solo favoritos'), value: soloFav, onChanged: (v) => setState(() => soloFav = v)),
        SegmentedButton<int>(
            segments: const [ButtonSegment(value: 5, label: Text('5')), ButtonSegment(value: 10, label: Text('10')), ButtonSegment(value: 20, label: Text('20'))],
            selected: {n},
            onSelectionChanged: (s) => setState(() => n = s.first)),
        if (err != null) Padding(padding: const EdgeInsets.all(8), child: Text(err!, style: const TextStyle(color: Colors.red))),
        const SizedBox(height: 12),
        FilledButton(onPressed: start, child: Text(fin ? 'Nuevo examen' : 'Comenzar examen')),
      ]);
    } else {
      final p = ps![i];
      cuerpo = ListView(padding: const EdgeInsets.all(16), children: [
        LinearProgressIndicator(value: (i + 1) / ps!.length),
        const SizedBox(height: 8),
        Text('${p.tipo} · ${i + 1}/${ps!.length}', style: TextStyle(color: Theme.of(c).colorScheme.secondary, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(p.enunciado, style: const TextStyle(fontSize: 16, height: 1.4)),
        const SizedBox(height: 12),
        for (var k = 0; k < p.ops.length; k++)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.all(14),
                  backgroundColor: sel == null ? null : (k == p.ok ? Colors.green.withOpacity(.3) : (k == sel ? Colors.red.withOpacity(.3) : null))),
              onPressed: sel == null ? () => resp(k) : null,
              child: Text(p.ops[k], textAlign: TextAlign.left),
            ),
          ),
        if (sel != null) ...[
          Text(sel == p.ok ? '✔ Correcto' : '✘ Incorrecto', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: sel == p.ok ? Colors.green : Colors.red)),
          seccion(c, 'Fundamento legal — Art. ${p.art.num}', p.art.texto),
          seccion(c, 'En palabras sencillas', p.art.s('explicacion')),
          FilledButton(onPressed: sig, child: Text(i + 1 >= ps!.length ? 'Finalizar' : 'Siguiente')),
        ],
      ]);
    }
    return Scaffold(appBar: AppBar(title: const Text('Exámenes')), body: cuerpo);
  }
}

// ───────────── CASOS ─────────────
class Casos extends StatelessWidget {
  const Casos({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Casos prácticos')),
        body: FutureBuilder<List>(
          future: _json('casos.json'),
          builder: (_, s) => !s.hasData
              ? const Center(child: CircularProgressIndicator())
              : ListView(children: [
                  for (final x in s.data!)
                    ListTile(leading: const Icon(Icons.gavel), title: Text(x['titulo']), subtitle: Text(frag(x['hechos'], 90)), onTap: () => ir(c, CasoPage(Map<String, dynamic>.from(x)))),
                ]),
        ),
      );
}

class CasoPage extends StatefulWidget {
  final Map<String, dynamic> c;
  const CasoPage(this.c, {super.key});
  @override
  State<CasoPage> createState() => _CasoS();
}

class _CasoS extends State<CasoPage> {
  final sel = <String>{};
  int? r;
  bool ver = false;
  final fund = <String, Art?>{};
  Future<void> _ver() async {
    for (final n in (widget.c['arts'] as List).cast<String>()) {
      fund[n] = await DB.art(n);
    }
    setState(() => ver = true);
  }

  @override
  Widget build(BuildContext ctx) {
    final x = widget.c;
    final ok = (x['arts'] as List).cast<String>().toSet();
    final ops = (x['ops'] as List).cast<String>();
    return Scaffold(
      appBar: AppBar(title: Text(x['titulo'])),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        seccion(ctx, 'Hechos', x['hechos']),
        const Padding(padding: EdgeInsets.fromLTRB(4, 12, 4, 4), child: Text('1. ¿Qué artículos de la LFT aplican?', style: TextStyle(fontWeight: FontWeight.bold))),
        Wrap(spacing: 6, children: [
          for (final n in (x['opciones'] as List).cast<String>())
            FilterChip(label: Text('Art. $n'), selected: sel.contains(n), onSelected: ver ? null : (v) => setState(() => v ? sel.add(n) : sel.remove(n))),
        ]),
        Padding(padding: const EdgeInsets.fromLTRB(4, 12, 4, 4), child: Text('2. ${x['pregunta']}', style: const TextStyle(fontWeight: FontWeight.bold))),
        for (var k = 0; k < ops.length; k++)
          ListTile(
              leading: Icon(r == k ? Icons.radio_button_checked : Icons.radio_button_unchecked),
              title: Text(ops[k]),
              tileColor: ver ? (k == x['ok'] ? Colors.green.withOpacity(.25) : (k == r ? Colors.red.withOpacity(.25) : null)) : null,
              onTap: ver ? null : () => setState(() => r = k)),
        const Padding(padding: EdgeInsets.fromLTRB(4, 12, 4, 4), child: Text('3. Tu análisis: derechos, obligaciones del patrón, qué reclamar y procedimiento', style: TextStyle(fontWeight: FontWeight.bold))),
        const TextField(minLines: 3, maxLines: 6, decoration: InputDecoration(border: OutlineInputBorder(), hintText: 'Escribe tu análisis y compáralo con la resolución')),
        const SizedBox(height: 12),
        if (!ver) FilledButton(onPressed: _ver, child: const Text('Ver resolución')),
        if (ver) ...[
          Text(
              'Artículos: ${sel.containsAll(ok) && sel.difference(ok).isEmpty ? '✔ correcto' : '✘ faltan: ${ok.difference(sel).join(', ')}${sel.difference(ok).isEmpty ? '' : ' · sobran: ${sel.difference(ok).join(', ')}'}'}\nConclusión: ${r == x['ok'] ? '✔ correcta' : '✘ incorrecta'}',
              style: const TextStyle(fontWeight: FontWeight.bold, height: 1.5)),
          seccion(ctx, 'Resolución explicada', x['resolucion']),
          seccion(ctx, 'Derechos involucrados', x['derechos']),
          seccion(ctx, 'Obligaciones del patrón', x['obligaciones']),
          seccion(ctx, 'Qué puede reclamar', x['reclamar']),
          seccion(ctx, 'Procedimiento', x['procedimiento']),
          for (final e in fund.entries)
            seccion(ctx, 'Fundamento — Art. ${e.key}', e.value?.texto ?? 'Importa el texto oficial para ver este artículo.'),
        ],
      ]),
    );
  }
}

// ───────────── GLOSARIO ─────────────
class Glosario extends StatefulWidget {
  const Glosario({super.key});
  @override
  State<Glosario> createState() => _GlS();
}

class _GlS extends State<Glosario> {
  String q = '';
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Diccionario jurídico')),
        body: FutureBuilder<List>(
          future: _json('glosario.json'),
          builder: (_, s) => !s.hasData
              ? const Center(child: CircularProgressIndicator())
              : Column(children: [
                  Padding(padding: const EdgeInsets.all(12), child: TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), border: OutlineInputBorder(), hintText: 'Buscar concepto'), onChanged: (v) => setState(() => q = v.toLowerCase()))),
                  Expanded(
                    child: ListView(children: [
                      for (final x in s.data!.where((x) => (x['t'] as String).toLowerCase().contains(q)))
                        ExpansionTile(title: Text(x['t']), subtitle: Text(x['tipo']), childrenPadding: const EdgeInsets.all(12), expandedCrossAxisAlignment: CrossAxisAlignment.start, children: [Text(x['def']), const SizedBox(height: 8), Text('Ejemplo: ${x['ej']}', style: const TextStyle(fontStyle: FontStyle.italic))]),
                    ]),
                  ),
                ]),
        ),
      );
}

// ───────────── PROGRESO ─────────────
class Progreso extends StatelessWidget {
  const Progreso({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Mi progreso')),
        body: FutureBuilder<Map<String, dynamic>>(
          future: DB.stats(),
          builder: (_, s) {
            if (!s.hasData) return const Center(child: CircularProgressIndicator());
            final m = s.data!;
            final tot = m['total'] as int, ap = m['aprendidos'] as int, pr = m['proceso'] as int;
            final ex = m['ex'] as Map;
            final exT = ex['t'] as int;
            final ref = (m['ref'] as List).cast<Map>();
            Widget k(String t, String v) => Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [Text(v, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Text(t, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12))]))));
            return ListView(padding: const EdgeInsets.all(12), children: [
              Text('Dominio: ${tot == 0 ? 0 : (100 * ap / tot).round()}%', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              LinearProgressIndicator(value: tot == 0 ? 0 : ap / tot, minHeight: 10),
              const SizedBox(height: 12),
              Row(children: [k('Racha (días)', '${m['racha']}'), k('Días estudiados', '${m['dias']}')]),
              Row(children: [k('Estudiados', '${ap + pr}/$tot'), k('Memorizados', '$ap')]),
              Row(children: [k('Exámenes', '${ex['n']}'), k('Aciertos', exT == 0 ? '—' : '${(100 * (ex['a'] as int) / exT).round()}%')]),
              const Padding(padding: EdgeInsets.only(top: 12), child: Text('Necesitan refuerzo', style: TextStyle(fontWeight: FontWeight.bold))),
              if (ref.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('Aún no hay artículos con más fallos que aciertos.')),
              for (final r in ref) ListTile(dense: true, leading: const Icon(Icons.warning_amber, color: oro), title: Text('Art. ${r['num']}'), subtitle: Text('Fallos: ${r['fallos']} · Aciertos: ${r['aciertos']}')),
            ]);
          },
        ),
      );
}

// ───────────── AJUSTES ─────────────
class Ajustes extends StatefulWidget {
  const Ajustes({super.key});
  @override
  State<Ajustes> createState() => _AjS();
}

class _AjS extends State<Ajustes> {
  void msg(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> importar() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['txt'], withData: true);
    if (r == null || r.files.single.bytes == null) return;
    final b = r.files.single.bytes!;
    String txt;
    try {
      txt = utf8.decode(b);
    } catch (_) {
      txt = latin1.decode(b);
    }
    final n = await DB.importar(txt);
    msg(n == 0 ? 'No se detectaron artículos. Revisa que el .txt tenga líneas «Artículo N.-».' : 'Se importaron $n artículos.');
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Ajustes')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Artículos nuevos por día', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          SegmentedButton<int>(
            segments: const [ButtonSegment(value: 5, label: Text('5')), ButtonSegment(value: 10, label: Text('10')), ButtonSegment(value: 15, label: Text('15'))],
            selected: {metaDiaria},
            onSelectionChanged: (s) async {
              final sp = await SharedPreferences.getInstance();
              await sp.setInt('meta', s.first);
              setState(() => metaDiaria = s.first);
            },
          ),
          const SizedBox(height: 20),
          const Text('Tema', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          SegmentedButton<ThemeMode>(
            segments: const [ButtonSegment(value: ThemeMode.system, label: Text('Auto')), ButtonSegment(value: ThemeMode.light, label: Text('Claro')), ButtonSegment(value: ThemeMode.dark, label: Text('Oscuro'))],
            selected: {modo.value},
            onSelectionChanged: (s) async {
              final sp = await SharedPreferences.getInstance();
              await sp.setInt('modo', s.first.index);
              setState(() => modo.value = s.first);
            },
          ),
          const Divider(height: 36),
          const Text('Texto oficial de la LFT', style: TextStyle(fontWeight: FontWeight.bold)),
          const Padding(
              padding: EdgeInsets.symmetric(vertical: 6),
              child: Text('Descarga la ley vigente de https://www.diputados.gob.mx/LeyesBiblio/, conviértela a .txt (UTF-8) e impórtala. Se actualiza el texto de cada artículo y se conservan tus explicaciones y progreso. Repite el proceso cuando haya reformas.')),
          FilledButton.icon(onPressed: importar, icon: const Icon(Icons.upload_file), label: const Text('Importar texto oficial (.txt)')),
          const Divider(height: 36),
          OutlinedButton(
            onPressed: () async {
              final ok = await showDialog<bool>(
                  context: c,
                  builder: (_) => AlertDialog(title: const Text('¿Reiniciar progreso?'), content: const Text('Se borrarán progreso, favoritos, exámenes e historial.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancelar')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Reiniciar'))]));
              if (ok == true) {
                await DB.reiniciar();
                msg('Progreso reiniciado');
              }
            },
            child: const Text('Reiniciar progreso'),
          ),
        ]),
      );
}
